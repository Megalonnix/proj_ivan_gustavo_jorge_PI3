# Projeto Integrador III — Motor de Busca Municipal e Histórico da Baixada Santista
**Alunos:** Ivan Guimarães dos S. da Silva, Jorge Sugano Suzart e Gustavo Geminiano  
**Repositório:** https://github.com/Megalonnix/proj_ivan_gustavo_jorge_PI3  
**Ambiente:** R base no Google Colab / IRkernel

---

## Estrutura Oficial do Repositório

```text
projeto_final/
├── 00_FICHA_PROJETO.md                 # Ficha técnica acumulada de todas as aulas (01 a 06)
├── README.md                           # Guia de navegação e visão geral do projeto
├── config.R                            # Configurações homologadas do motor (BM25, limiar, PRF)
├── corpus.csv                          # 132 parágrafos autônomos congelados (minimo = 200)
├── wikipedia_baixada_santista.csv      # Corpus bruto extraído da Wikipédia
├── necessidades.csv                    # 12 necessidades de busca (conjunto: dev e teste)
├── qrels_jorge_2026-10-13.csv          # 230 julgamentos de relevância (juiz Jorge, grau 2)
├── consolidados/                       # Relatórios semanais de teoria e sessões de grupo (Parte D)
│   ├── 00_FICHA_PROJETO.md
│   ├── aula00_consolidado.md
│   ├── aula00_parteD_consolidado.md
│   ├── aula01_consolidado.md
│   ├── aula01_parteD_consolidado.md
│   ├── aula02_consolidado.md
│   ├── aula02_parteD_consolidado.md
│   ├── aula03_consolidado.md
│   ├── aula03_parteD_consolidado.md
│   ├── aula04_consolidado.md
│   ├── aula04_parteD_consolidado.md
│   ├── aula05b_consolidado.md
│   ├── aula05b_parteD_consolidado.md
│   ├── aula06_consolidado.md
│   └── aula06_parteD_consolidado.md
├── estrutura/
│   ├── codigo/                         # Notebooks executáveis e configurações
│   │   ├── config.R
│   │   ├── Aula00_Teoria.ipynb
│   │   ├── Aula00_ParteD.ipynb (aula00.ipynb)
│   │   ├── Aula01_Teoria.ipynb
│   │   ├── Aula01_ParteD.ipynb (aula01.ipynb)
│   │   ├── Aula02_Teoria.ipynb
│   │   ├── Aula02_ParteD.ipynb (aula02.ipynb)
│   │   ├── Aula03_Teoria.ipynb
│   │   ├── Aula03_ParteD.ipynb (aula03.ipynb)
│   │   ├── Aula04_Teoria.ipynb
│   │   ├── Aula04_ParteD.ipynb (aula04.ipynb)
│   │   ├── Aula05b_Teoria.ipynb
│   │   ├── Aula05b_ParteD.ipynb (aula05b.ipynb)
│   │   ├── Aula06_Teoria.ipynb
│   │   └── Aula06_ParteD.ipynb (aula06.ipynb)
│   └── bancoDeDados/                   # Bases de dados oficiais do projeto
│       ├── corpus.csv
│       ├── wikipedia_baixada_santista.csv
│       ├── necessidades.csv
│       └── qrels_jorge_2026-10-13.csv
├── guias_estudo/                       # Guias de estudo originais do professor (Aulas 00 a 06)
│   ├── GUIA_ESTUDO_aula00_teoria.md
│   ├── GUIA_ESTUDO_aula00_parteD.md
│   ├── ...
│   └── GUIA_ESTUDO_aula06_parteD.md
└── projeto.zip                         # Arquivo compactado para submissão direta
```

---

## Resumo dos Resultados Experimentais Homologados

1. **Aulas 00–02:** Fundação vetorial com TF-IDF e Similaridade do Cosseno ($N=132$).
2. **Aula 03:** Limpeza (`translit`), remoção de 27 stopwords e indexação invertida (3.483 termos).
3. **Aula 04:** BM25 construído com parâmetros canônicos ($k_1=1{,}2$ e $b=0{,}75$).
4. **Aula 05,5:** Avaliação com gabarito de 230 qrels. Empate exato em 6 a 6 entre Cosseno (MAP $0{,}640$) e BM25 (MAP $0{,}637$), P@3 de $0{,}917$ em ambos.
5. **Aula 06:** 
   - Rocchio na coleção completa aparenta salto ($0{,}780 	o 0{,}947$), mas na coleção residual cai ($0{,}649 	o 0{,}498$), provando o viés de reordenação dos documentos já vistos.
   - PRF provoca *query drift* em consultas curtas ($MAP_{dev}: 0{,}653 	o 0{,}448$; $MAP_{teste}: 0{,}612 	o 0{,}487$).
   - Decisão homologada em `config.R`: `prf_k = 0` (desativada em produção) e `rocchio = c(a = 1, b = 0.75, g = 0.15)`.
